let display = document.getElementById('display');
let currentOperator = '';
let firstNumber = '';
let secondNumber = '';

function appendNumber(number) {
    display.value += number;
}

function setOperator(operator) {
    firstNumber = display.value;
    currentOperator = operator;
    display.value = '';
}

function calculate() {
    secondNumber = display.value;
    let result;
    switch (currentOperator) {
        case '+':
            result = parseFloat(firstNumber) + parseFloat(secondNumber);
            break;
        case '-':
            result = parseFloat(firstNumber) - parseFloat(secondNumber);
            break;
        case '*':
            result = parseFloat(firstNumber) * parseFloat(secondNumber);
            break;
        case '/':
            result = parseFloat(firstNumber) / parseFloat(secondNumber);
            break;
        default:
            return;
    }
    display.value = result;
}

function clearDisplay() {
    display.value = '';
    currentOperator = '';
    firstNumber = '';
    secondNumber = '';
}
